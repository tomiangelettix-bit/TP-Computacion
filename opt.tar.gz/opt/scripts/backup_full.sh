#!/bin/bash

#----------------------AYUDA---------------------------
if [[ "$1" == "-help" ]]; then
    echo "Uso: $0 ORIGEN DESTINO"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 0
fi

#----------------VALIDACIÓN DE PARÁMETROS--------------
if [[ $# -ne 2 ]]; then
    echo "Error: se requieren dos parámetros."
    echo "Use: $0 -help para ver cómo usarlo."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: el directorio de origen no existe."
    exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
    echo "Error: el directorio de destino no existe."
    exit 1
fi

#-----------VALIDACIÓN DE SISTEMAS DE ARCHIVOS---------
df "$ORIGEN" >/dev/null 2>&1 || { echo "Error: el sistema de archivos de ORIGEN no está disponible"; exit 1; }
df "$DESTINO" >/dev/null 2>&1 || { echo "Error: el sistema de archivos de DESTINO no está disponible"; exit 1; }

#-----------------------BACKUP--------------------------
FECHA=$(date +%Y%m%d)
NOMBRE_ORIGEN=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE_ORIGEN}_bkp_${FECHA}.tar.gz"

echo "Generando backup..."

tar -czpf "$DESTINO/$ARCHIVO" -C "$ORIGEN" .

if [[ $? -eq 0 ]]; then
    echo "Backup finalizado correctamente: $DESTINO/$ARCHIVO"
else
    echo "Error al generar el backup."
fi